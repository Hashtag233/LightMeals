package hashmod.lightmeals;

public class Utils {
    public static final String MODID = "lightmeals";
}
